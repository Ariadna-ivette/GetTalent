
import React from 'react';
import './Input.css';

//El atributo maneja el id, name, placeholder, type
//HandleChange (manejador de eventos) trae el evento
//El classname va ir cambiando dependiendo el aprametro
//Los parametros validan la información que se ingresa, nos ayuda a mandar las alertas

const Input = ({attribute, handleChange, param, errorpassword}) => {
    return(
        <div className='input-register'>
            <input
                id={attribute.id}
                name={attribute.name}
                placeholder={attribute.placeholder}
                type={attribute.type}
                required={attribute.required}
                pattern={attribute.pattern}
                //onChange={(e)=> handleChange(e.target.name, e.target.value)}
                onChange={handleChange}
                className= {param ? 'input-error' : 'regular-style'}
            />
            <span>{errorpassword}</span>

        </div>
    )
};

export default Input;