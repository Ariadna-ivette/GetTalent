import React from "react";
import './label-input.css';

const Label = ({text}) => {
    return (
        <div className='label-input'>
            <label> {text} </label>
        </div>
    )
};

export default Label;