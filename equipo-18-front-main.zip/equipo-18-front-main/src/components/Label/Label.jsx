import React from "react";
import './Label.css';

const Label = ({text, color}) => {

    return(
        <div className='label-container'>
            <label style={{color}}>{text}</label>

        </div>
    )
};

export default Label;