import React from "react";
import './Texto.css';

const Texto = ({text}) => {
    return(
        <div className='texto'>
            <a>{text}</a>
        </div>
    )
};

export default Texto;