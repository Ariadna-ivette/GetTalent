import React, { useState, useEffect } from "react";
import { myAxios } from "../../utils/api";

import "./PerfilIntereses.css";

import Title from "../../components/Title/Title";
import Label from "../../components/Label/Label";
import "toastify-js/src/toastify.css"
import Toastify from 'toastify-js'
import { Navigate, useNavigate } from "react-router-dom";

function PerfilIntereses() {
  const [formValues, setFormValues] = useState({
    area: "",
    rol: "",
    mode: "",
    type: "",
  });

  const [isSubmit, setIsSubmit] = useState(false);
  const [data, setData] = useState("");
  const navigate = useNavigate();

  const sendData = async () => { navigate("/AcademicInfo")
    try {
       await myAxios({
        method: "get",
        url: "applicant/interestarea/",
        data: formValues,
      }); Toastify({
        text: "Tus datos han sido guardados con éxito",
        duration: 3000
        }).showToast();
    } catch (error) {
      console.log(error)
      Toastify({
        text: "Tus datos no han sido guardados",
        duration: 3000
        }).showToast()
    }
  };


  function handleSubmit(e) {
    e.preventDefault();
    sendData();
    setIsSubmit(true);
  }

  const handleChange = (event) => {
    setFormValues({
      ...formValues,
      [event.target.name]: event.target.value,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="container-intereses">
      <Title text="GET TALENT" />

      <Label text="Querémos conocerte más. Cuéntanos sobre tus intereses." />

      <p className="label">¿En qué área te interesa trabajar?</p>
      <select className="input-texto" name="area" onChange={handleChange}>
        <option selected disabled>
          Elige de la lista
        </option>
        <option value="Finanzas">Finanzas</option>
        <option value="Ventas">Ventas</option>
        <option value="Tecnología">Tecnología</option>
        <option value="Inmobiliaria">Inmobiliaria</option>
      </select>

      <p className="label">Selecciona el rol</p>
      <select className="input-texto" name="rol" onChange={handleChange}>
        <option selected disabled>
          Elige de la lista
        </option>
        <option value="Finanzas1">Gerente administrativo</option>
        <option value="Finanzas2">Contador</option>
        <option value="Ventas1">Supervisor de ventas</option>
        <option value="Ventas2">Asesor de ventas</option>
        <option value="Tecnología1">Front-end developer</option>
        <option value="Tecnología2">Back-end developer</option>
        <option value="Inmobiliaria1">Promotor inmobiliario</option>
        <option value="Inmobiliaria2">Asesor inmobiliario</option>
      </select>

      <p className="label">¿En qué modalidad quieres trabajar?</p>
      <select className="input-texto" name="mode" onChange={handleChange}>
        <option selected disabled>
          Elige de la lista
        </option>
        <option value="Presencial">Presencial</option>
        <option value="Remoto">Remoto</option>
        <option value="Híbrido">Híbrido</option>
      </select>

      
      <p className="label">Tipo de contrato</p>
      <select className="input-texto" name="type" onChange={handleChange}>
        <option selected disabled>
          Elige de la lista
        </option>
        <option value="Tiempo completo">Tiempo completo</option>
        <option value="Medio tiempo">Medio tiempo</option>
        <option value="Prácticas">Prácticas</option>
      </select>

      <br></br>

      <button type="submit" className="guardar-button" onSubmit={handleSubmit}>
        Guardar
      </button>

    </form>
  );
}

export default PerfilIntereses;
