import React,{useState} from "react"
import "./Presentation.css";
import Title from "../../components/Title/Title";
import Label from "../../components/Label/Label";
import Input from "../../components/Input/Input";
import { myAxios } from "../../utils/api";
import "toastify-js/src/toastify.css"
import Toastify from 'toastify-js'

export default function Presentation() {
    //Aquí van las funciones
    //Primero declaramos los use state

  const [url, setUrl] = useState("");
  const [isUrl, setIsUrl] = useState(false);
  const [errorUrl, setErrorUrl] = useState(false);
  const [error, setError] = useState('');


  // Funciones
  const handleSubmit= async (e) =>{
   
    e.preventDefault();
        try {
          await myAxios({
            method: "post",
            url: "video/edit/",
            data: {
            linkVideo: "",
            },
          }); Toastify({
            text: "Tu video se subió exitosamente",
            duration: 3000
            }).showToast();
        } catch (error) {console.log(error)}
    console.log(url)
    let regExQ =/^(https?:\/\/www.)[a-zA-Z0-9-_$]+.[a-zA-Z]{2,5}$/g;
    let isOk=regExQ.test(url)
    console.log(isOk)
    if(url===""){
      console.log("¡Escribe tu URL!")
      //alert("Escribe tu nombre completo")
      setErrorUrl(true)
    }
    else{setErrorUrl(false)}
    //console.log(e.target.value)
  }

  const handleChange=(e) => {
    console.log(e.target.value) //"está imprimiendo en consola"
    setUrl(e.target.value)
  }

    //Aquí regresan los componentes
    return (
        <>
        <form onSubmit={handleSubmit}>
          <div className="presentation-container">
            <div className="logotipo-login">
            {/*  <img src={LogoGetTalent} /> */}
            </div>
            <div className="presentation-sections">
              <Title text="GET TALENT" />
             <Label text="Video de presentación" />
             <p>Sube un video presentandote y contandonos un poco de tu perfil.</p>
              <input
          className="input-url"
          name="url"
          placeholder="Ingrese su URL"
          onChange={handleChange}
        />
                <p className="label-errors"> 
        {errorUrl ? <Label text="Escribe tu URL" />:null}</p>
        {/*<p className="reminder">{errorUrl ? <Label 
        text="Tu url debe tener la siguiente estructura http://www._____.com" />:null}</p>*/}
              {errorUrl && (
                <label className="label-alert">
                  {error}
                </label>
              )}
                <button className="button-submit" type="submit" >
                Agregar
              </button>
              </div>
          </div>
        </form>
      </>
    )
}

