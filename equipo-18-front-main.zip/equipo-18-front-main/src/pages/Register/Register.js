import React, { useState, useEffect } from "react";
import "./Register.css";
import Title from "../../components/Title/Title";
import Label from "../../components/Label/Label";
import Input from "../../components/Input/Input";
// este conecta as historias
import { Link } from "react-router-dom";
import { toHaveFormValues } from "@testing-library/jest-dom/dist/matchers";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { formControlClasses } from "@mui/material";

const Register = () => {
  const [user, setUser] = useState({
    nombre: "",
    apellidos: "",
    correo: "",
    usuario: "",
    contraseña: "",
    confirmar: "",
    role: 0,
  });

  // 1.- Esta constante llama a los valores de los inputs, estado inicial.
  const initialValues = {
    nombre: "",
    apellidos: "",
    correo: "",
    usuario: "",
    contraseña: "",
    confirmar: "",
    role_AE: 0,
  };
  console.log(user);
  // 2.- Creas los estados (useState) los llamas con la constante.
  // 3.- En los inputs agregas el valor como formValues
  const [formValues, setFormValues] = useState(initialValues);
  const [formErrors, setFormErrors] = useState({});
  const [isSubmit, setIsSubmit] = useState(false);
  const navigate = useNavigate();

  //Función arrow onChange:
  const handleChange = (event) => {
    setUser({
      ...user,
      [event.target.name]: event.target.value,
    });
  };

  const handleSubmit = (event) => {
    setFormErrors(validate(formValues));
    setIsSubmit(true);

    event.preventDefault();
    axios
      .post("https://floating-journey-82290.herokuapp.com/auth/signup/", {
        email: user.correo,
        password: user.contraseña,
        confirm_password: user.confirmar,
        role_AE: user.role_AE,
      })
      .then(
        (res) => console.log("respuesta", res.data.tokens.access),
        navigate("/DatosPerfil")
      )
      .catch((error) => console.log("error", error));
    console.log(
      user.nombre +
        " " +
        user.apellidos +
        " " +
        user.correo +
        " " +
        user.usuario +
        " " +
        user.contraseña +
        " " +
        user.confirmar
    );
  };

  useEffect(() => {
    console.log(formErrors);
    if (Object.keys(formErrors).length === 0 && isSubmit) {
      console.log(formValues);
    }
  });

  const validate = (formValues) => {
    const errors = {};
    const regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,})+$/;
    if (!user.nombre) {
      errors.nombre = "Introduce tu nombre";
    }
    if (!user.apellidos) {
      errors.apellidos = "Introduce tus apellidos";
    }
    if (!user.correo) {
      errors.correo = "Introduce tu dirección de e-mail";
    } else if (!regex.test(user.correo)) {
      errors.correo = "Este e-mail no es válido";
    }
    if (!user.usuario) {
      errors.usuario = "Introduce tu nombre de usuario";
    }
    if (!user.contraseña) {
      errors.contraseña = "Introduce una contraseña";
    } else if (!user.contraseña < 6) {
      errors.contraseña = "La contraseña debe ser mayor a 6 caracteres";
    }
    if (!user.confirmar) {
      errors.confirmar = "Confirma tu contraseña";
    }
    return errors;
  };

  return (
    <div className="background-container">
      <form onSubmit={handleSubmit}>
        <div className="register-container">
          <Title text="GET TALENT" />

          <Label text="¡Bienvenido! Registrate aquí" />

          {/*<Input
          attribute={{
            id: "Nombre",
            name: "nombre",
            type: "text",
            placeholder: "Nombre",
            //onChange es para cuando se mete un valor en el input, este se actualiza al valor ingresado.
            onChange: { handleChange },
          }}
          handleChange={handleChange}
        />
        <p className="label-error">{formErrors.nombre}</p>*/}

          {/*<Input
          attribute={{
            id: "Apellidos",
            name: "apellidos",
            type: "text",
            placeholder: "Apellidos",
            onChange: { handleChange },
          }}
          handleChange={handleChange}
        />
        <p className="label-error">{formErrors.apellidos}</p>
        */}

          <Input
            attribute={{
              id: "Correo",
              name: "correo",
              type: "email",
              placeholder: "Correo",
              required: true,
              onChange: { handleChange },
            }}
            handleChange={handleChange}
          />
          <p className="label-error">{formErrors.correo}</p>

          {/*<Input
          attribute={{
            id: "Usuario",
            name: "usuario",
            type: "text",
            placeholder: "Usuario",
            onChange: { handleChange },
          }}
          handleChange={handleChange}
        />
        <p className="label-error">{formErrors.usuario}</p>
        */}

          <Input
            attribute={{
              id: "Contraseña",
              name: "contraseña",
              type: "password",
              placeholder: "Contraseña",
              required: true,
              onChange: { handleChange },
            }}
            handleChange={handleChange}
          />
          <p className="label-error">{formErrors.contraseña}</p>

          <Input
            attribute={{
              id: "Confirmar",
              name: "confirmar",
              type: "password",
              placeholder: "Confirma tu contraseña",
              required: true,
              onChange: { handleChange },
            }}
            handleChange={handleChange}
          />
          <p className="label-error">{formErrors.confirmar}</p>
          <label className="label-input">
            La contraseña debe tener 6 caractéres, mayúscula, número y caracter
            especial.
          </label>

          <label className="label-input">Selecciona tu rol:</label>
          <select
            className="input-texto"
            name="role_AE"
            onChange={handleChange}
          >
            <option selected disabled>
              Elige de la lista
            </option>
            <option value={0}>Solicitante</option>
            <option value={1}>Empleador</option>
          </select>

          <div>
            <button type="submit">Registrarse</button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default Register;
