import React, { useState, useEffect } from "react";
import "./ConfirmRegister.css";
// este conecta as historias
import axios from "axios";
import { useNavigate } from "react-router-dom";

const ConfirmRegister = () => {

    return (
        <div>
            <h2 className="título">¡Bienvenido a la plataforma de GET TALENT!</h2>
            <p className="texto">Revisa tu correo y haz click en confirmar cuenta</p>
            <link>Haz Login aquí</link>
        </div>
    )
}




export default ConfirmRegister;