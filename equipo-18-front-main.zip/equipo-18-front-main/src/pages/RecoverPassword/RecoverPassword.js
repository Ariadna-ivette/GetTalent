import React, { useState } from "react";

import "./RecoverPassword.css";

import Title from "../../components/Title/Title";
import Label from "../../components/Label/Label";

import { myAxios } from "../../utils/api";
import { useNavigate } from "react-router-dom";
import "toastify-js/src/toastify.css"
import Toastify from 'toastify-js'

function RecoverPassword() {
  const [formValues, setFormValues] = useState({
    email: "",
  });
  const [isSubmit, setIsSubmit] = useState(false);

  const sendData = async () => {
    try {
      const { data } = await myAxios({
        method: "post",
        url: "auth/request-recovery-password/ ",
        data: formValues,
      })
      Toastify({
        text: "Se ha enviado un correo con los pasos a seguir.",
        duration: 3000
        }).showToast();
    } catch (error) {
      console.log(error);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    sendData();
    setIsSubmit(true);
  };

  const handleChange = (e) => {
    e.preventDefault();
  };

  return (
    <form onSubmit={handleSubmit} className="datos-container">
      <div>
        <Title text="GET TALENT" />

        <h2 className="h2">¿Olvidaste tu contraseña?</h2>

        <p className="label">
          No te preocupes. Ingresa tu contraseña aquí y espera el mail de
          confirmación para cambiarla.
        </p>
        <br />
        <input
          className="input"
          name="email"
          type="email"
          required
          placeholder="Ingresa tu email registrado"
          onChange={handleChange}
        />

        <br />

        <button
          type="submit"
          className="guardar-button"
          onSubmit={handleSubmit}
        >
          Enviar
        </button>
      </div>
    </form>
  );
}

export default RecoverPassword;
