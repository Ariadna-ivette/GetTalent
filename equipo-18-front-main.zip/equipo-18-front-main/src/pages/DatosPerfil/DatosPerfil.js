import React, { useState, useEffect } from "react";
import { myAxios } from "../../utils/api";
import "./DatosPerfil.css";
import Title from "../../components/Title/Title";
import Label from "../../components/Label/Label";
import "toastify-js/src/toastify.css"
import Toastify from 'toastify-js'


//para conectar historia
import { Navigate, useNavigate } from "react-router-dom";
import PerfilIntereses from "pages/PerfilIntereses/PerfilIntereses";

function DatosPerfil() {
  const [formValues, setFormValues] = useState({
    name: "",
    last_nameP: "",
    last_nameM: "",
    sex: "",
    birth: "",
    age: "",
    marital_status: "",
    email: "",
    address: "",
    state: "",
    municipality: "",
  });
  

  const [isSubmit, setIsSubmit] = useState(false);
  const [data, setData] = useState("");
  const navigate = useNavigate();

  const sendData = async () => { navigate("/PerfilIntereses")
    try {
      await data ? myAxios({
        method: "put",
        url: "applicant/editpersonaldata/",
        data: formValues,
      }): myAxios({
        method: "post",
        url: "applicant/registerpersonaldata/",
        data: formValues,
        
      })
      Toastify({
        text: "Guardaste tus datos con éxito",
        duration: 3000
        }).showToast();
        
        
        
    } catch (error) {
      console.log(error)
      Toastify({
        text: "Tus datos no han sido guardados",
        duration: 3000
        }).showToast()
    }
  };

  const getData = async () => {
    try {
      const {data} = await myAxios({
        method: "get",
        url: "applicant/viewpersonaldata/",
      })

      setData(data)
      
    } catch (error) {
      console.log(error)
    }
  };


  function handleSubmit(e) {
    e.preventDefault();
    sendData();
    setIsSubmit(true);
    /*axios
      .post("https://floating-journey-82290.herokuapp.com/applicant/registerpersonaldata/", {
        ...formValues,
      })
      .then(
        (res) =>
          window.localStorage.setItem("codecatstoken", res.data.tokens.access))//para guardar en localstorage 
      .catch((error) => console.log("error", error));*/
  
  }

  const handleChange = (event) => {
    setFormValues({
      ...formValues,
      [event.target.name]: event.target.value,
    });
  };

  useEffect(() => {
    getData()
  },[])
  ;

  return (
    <form onSubmit={handleSubmit} className="datos-container">
      <Title text="GET TALENT" />

      <Label text="Ingresa tus datos personales" />

      <input
        className="input-texto"
        name="name"
        type="text"
        required
        placeholder="Nombre(s)"
        onChange={handleChange}
      />

      <input
        className="input-texto"
        name="last_nameP"
        type="text"
        required
        placeholder="Apellido paterno"
        onChange={handleChange}
      />

      <input
        className="input-texto"
        name="last_nameM"
        type="text"
        required
        placeholder="Apellido materno"
        onChange={handleChange}
      />

      <p className="label">¿Cómo te identificas?</p>
      <select className="input-texto" name="sex" onChange={handleChange}>
        <option selected disabled>
          Elige de la lista
        </option>
        <option value="Femenino">Femenino</option>
        <option value="Masculino">Masculino</option>
        <option value="Otro">Otro</option>
        <option value="Prefiero no decirlo">Prefiero no decirlo</option>
      </select>

      <p className="label">Fecha de nacimiento</p>

      <input
        className="input-texto"
        name="birth"
        type="date"
        required
        onChange={handleChange}
      />

      <p className="label">¿Cuántos años tienes?</p>

      <input
        className="input-texto"
        name="age"
        type="number"
        required
        onChange={handleChange}
      />

      <p className="label">Estado civil</p>

      <select
        className="input-texto"
        name="marital_status"
        onChange={handleChange}
      >
        <option selected disabled>
          Elige de la lista
        </option>
        <option value="Soltera(o)">Soltera(o)</option>
        <option value="Casada(o)">Casada(o)</option>
        <option value="Viuda(o)">Viuda(o)</option>
      </select>

      <p className="label">Ingresa tu email</p>
      <input
        className="input-texto"
        name="email"
        type="email"
        required
        placeholder="email"
        onChange={handleChange}
      />

      <p className="label">Dirección</p>

      <input
        className="input-texto"
        name="address"
        type="text"
        required
        placeholder="Calle y número"
        onChange={handleChange}
      />

      <input
        className="input-texto"
        name="municipality"
        type="text"
        required
        placeholder="Ciudad"
        onChange={handleChange}
      />

      <input
        className="input-texto"
        name="state"
        type="text"
        required
        placeholder="Estado"
        onChange={handleChange}
      />

      <button type="submit" className="guardar-button" onSubmit={handleSubmit}>
        Guardar
      </button>

    

    </form>
  );
}

export default DatosPerfil;
