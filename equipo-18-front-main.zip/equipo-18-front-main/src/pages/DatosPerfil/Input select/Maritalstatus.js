import React from "react";
import Select from "react-select";

import "./Inputselect.css";

function Maritalstatusddl() {
  var maritallist = [
    {
      value: 1,
      label: "Soltera(o)",
    },
    {
      value: 2,
      label: "Casada(o)",
    },
    {
      value: 3,
      label: "Viuda(o)",
    },
  ];

  return (
    <div className ='react-select-container'>
      <Select  options={maritallist} />
    </div>
  );
}

export default Maritalstatusddl;