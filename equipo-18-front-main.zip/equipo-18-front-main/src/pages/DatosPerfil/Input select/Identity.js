import React from "react";
import Select from "react-select";

import "./Inputselect.css";

function Identityddl() {
  var identitylist = [
    {
      value: 1,
      label: "Femenino",
    },
    {
      value: 2,
      label: "Masculino",
    },
    {
      value: 3,
      label: "No binario",
    },
    {
      value: 4,
      label: "Prefiero no declarar",
    },
  ];

  return (
    <div className ='react-select-container'>
      <Select options={identitylist} />
    </div>
  );
}

export default Identityddl;