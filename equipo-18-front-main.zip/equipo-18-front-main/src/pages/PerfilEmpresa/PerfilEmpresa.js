import React, { useState, useEffect } from "react";
import { myAxios } from "../../utils/api";

import "./PerfilEmpresa.css";

import Title from "../../components/Title/Title";
import Label from "../../components/Label/Label";
import { Navigate, useNavigate } from "react-router-dom";
import "toastify-js/src/toastify.css"
import Toastify from 'toastify-js'

import { Link } from "react-router-dom";
import { toHaveDescription } from "@testing-library/jest-dom/dist/matchers";

/*const PerfilEmpresa = () => {
  const [user, setUser] = useState({ business: "", description: "" });*/


  function PerfilEmpresa() {

  const [isSubmit, setIsSubmit] = useState(false);
  const [counter, setCounter] = useState(0);
  const [input, setInput] = useState({
    nameBussiness: "",
    descriptionBussiness:"",
  })
  const navigate = useNavigate();

const sendData = async () => { navigate("/RegistroVacantes")
  try {
    await myAxios({
      method:"post", 
      url:"employer/Employerscreate/", 
      data: input,
    }); Toastify({
      text: "Los datos han sido guardados con éxito",
      duration: 3000
      }).showToast();
  } catch (error) {
    console.log(error)
  }
}

  const handleChange = (e) => {
    //console.log(e.target);
    e.preventDefault()
    
    const { name, value } = e.target;
    setInput((prev) => ({
      ...prev,
      [name]:value,
    })) 
    const descriptionLength = input.descriptionBussiness.length
    setCounter(descriptionLength)
    //const descriptionLength = internalFormValues?.descriptionBusiness?.length
    //setCounter(descriptionLength)
    //console.log(internalFormValues.descripcion.length)
    //setFormValues(internalFormValues);
    //console.log(formValues);
  };
  console.log(input)

  const handleSubmit = (e) => {
    e.preventDefault();
    sendData();
    setIsSubmit(true);
  };

  /*useEffect(() => {
    console.log(formErrors);
    if (Object.keys(formErrors).length === 0 && isSubmit) {
      console.log(formValues);
    }
  }, [formErrors]);

  const validate = (values) => {
    const errors = {};
    if (!values.nameBusiness) {
      errors.nameBusiness = "El nombre de tu empresa es requerido";
    }
    if (!values.descriptionBusiness) {
      errors.descriptionBusiness = "La descripción de tu empresa es requerida";
    } else if (values.descriptionBusiness.length < 10) {
      errors.descriptionBusiness = "la descripción debe ser mayor a 10 caractéres";
    }
    return errors;
  };*/

  return (
    <form onSubmit={handleSubmit}>
      
      <div className="perfil-empresa-container">
        <Title text="GET TALENT" />

        <Label text="Ingresa los datos de tu empresa" />

        <p className="label">Nombre de empresa</p>
        <div className="form">
          <input
            className="input"
            name="nameBussiness"
            type="text"
            required
            onChange={handleChange}
          />

        

          <p className="label">
            {` Breve descripción de tu empresa ${counter}/1500`}
          </p>

          <textarea
            className="input-textarea"
            name="descriptionBussiness"
            type="text"
            control="textarea"
            label="descripcion"
            maxLength={1500}
            minLength={45}
            rows="10"
            onChange={handleChange}
          />

        
        </div>

        <p className="label"> Sube el logo de tu empresa</p>

        <button
          /*type="submit"*/ className="button-upload" /*onClick={handleSubmit}*/
        >
          Subir
        </button>

        <button type="submit" className="guardar-button">
          Guardar
        </button>
      </div>
    </form>
  );
}

export default PerfilEmpresa;
