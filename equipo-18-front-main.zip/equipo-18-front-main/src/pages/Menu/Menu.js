import React, { useState } from "react";

import "./Menu.css";

import Title from "../../components/Title/Title";
import Label from "../../components/Label/Label";

import { myAxios } from "../../utils/api";
import { useNavigate } from "react-router-dom";
import "toastify-js/src/toastify.css";
import Toastify from "toastify-js";
import { Link } from "react-router-dom";

function Menu() {
 
  return (
    <form className="background">
      <div className="nav-bar">
        <Title text="GET TALENT" />

        <Link className="link-miperfil" to="/DatosPerfil">
          Mi perfil
        </Link>

        <Link className="link-miperfil" to="">
          Mis postulaciones
        </Link>

        <Link className="link-miperfil" to="/PerfilEmpresa">
          Empresa
        </Link>
      </div>

      <div>
        <br />
        <h2 className="label-h2">¡Bienvenida!</h2>

        <br />


        <p className="text">
          Inicia ingresando tus datos personales y experiencia laboral. Haz
          click en "Mi perfil" para iniciar.
        </p>
      </div>
    </form>
  );
}

export default Menu;
