import React, { useState, useEffect } from "react";

import "./RegistroVacantes.css";

import Title from "../../components/Title/Title";
import Label from "../../components/Label/Label";
import Input from "../../components/Input/Input";
// este conecta as historias
import { Link } from "react-router-dom";
import { toHaveFormValues } from "@testing-library/jest-dom/dist/matchers";
import axios from "axios";
import { myAxios } from "../../utils/api";
import "toastify-js/src/toastify.css"
import Toastify from 'toastify-js'
import { Navigate, useNavigate } from "react-router-dom";

const RegistroVacantes = () => {
    const [vacante, setVacante] = useState({
      area: "",
      rol: "",
      tipoDeTrabajo: "",
      modalidad: "",
      descripcionDelPuesto: "",
      requisitos: "",
      linkDelVideoExplicativo: "",
      sueldo: "",
      localidad: "",
      pregunta1: "",
      pregunta2: "",
      pregunta3: "",
    });

    const initialValues = {
      area: "",
      rol: "",
      tipoDeTrabajo: "",
      modalidad: "",
      descripcionDelPuesto: "",
      requisitos: "",
      linkDelVideoExplicativo: "",
      sueldo: "",
      localidad: "",
      pregunta1: "",
      pregunta2: "",
      pregunta3: "",
    };

    const [formValues, setFormValues] = useState(initialValues);
    const [formErrors, setFormErrors] = useState({});
    const [isSubmit, setIsSubmit] = useState(false);
    const navigate = useNavigate();

    const handleChange = (e) => {
        setVacante({
          ...vacante,
          [e.target.name]: e.target.value,
        });
    };
    
    const handleSubmit = async (e) => { navigate("/AGREGAR AQUIIIIIIIIII") //siempre se tiene que poner async cuando usas await
    
        setFormErrors(validate(formValues));
        setIsSubmit(true);

        e.preventDefault();
        try {
          await myAxios({
            method: "post",
            url: "vacancies/posted/",
            data: {
            area: vacante.area,
            rol: vacante.rol,
            tipoDeTrabajo: vacante.tipoDeTrabajo,
            modality: vacante.modalidad,
            job_description: vacante.descripcionDelPuesto,
            requirements: vacante.requisitos,
            visual_explanation: vacante.linkDelVideoExplicativo,
            salary: vacante.sueldo,
            localidad: vacante.localidad,
            question_one: vacante.pregunta1,
            question_two: vacante.pregunta2,
            question_three: vacante.pregunta3,
            isopen: true,
            },
          }); Toastify({
            text: "Registraste tu vacante con éxito",
            duration: 3000
            }).showToast();
        } catch (error) {console.log(error)}
       {/*} axios.post("", {
            area: vacante.area,
            rol: vacante.rol,
            tipoDeTrabajo: vacante.tipoDeTrabajo,
            modalidad: vacante.modalidad,
            descripcionDelPuesto: vacante.descripcionDelPuesto,
            requisitos: vacante.requisitos,
            linkDelVideoExplicativo: vacante.linkDelVideoExplicativo,
            sueldo: vacante.sueldo,
            localidad: vacante.localidad,
            pregunta1: vacante.pregunta1,
            pregunta2: vacante.pregunta2,
            pregunta3: vacante.pregunta3,
          })
          .then((res) => console.log("respuesta", res.data.tokens.access))
        .catch((error) => console.log("error", error));*/}
        console.log(
            vacante.area +
            " " +
            vacante.rol +
            " " +
            vacante.tipoDeTrabajo +
            " " +
            vacante.modalidad +
            " " +
            vacante.descripcionDelPuesto +
            " " +
            vacante.requisitos +
            " " +
            vacante.linkDelVideoExplicativo +
            " " +
            vacante.sueldo  +
            " " +
            vacante.localidad +
            " " +
            vacante.pregunta1 +
            " " +
            vacante.pregunta2 +
            " " +
            vacante.pregunta3
        );
        };
        const validate = (formValues) => {
            const regex = /^(https?:\/\/www.)[a-zA-Z0-9-_$]+.[a-zA-Z]{2,5}$/g;
            const errors = {};

            if (!regex.test(vacante.linkDelVideoExplicativo)) {
                errors.linkDelVideoExplicativo = "Tu URL no es válida";
            }
            return errors;
        }

        return (
            <form onSubmit={handleSubmit}>
              <div className="vacantes-container">
                <Title text="GET TALENT" />
        
                <Label text="¡Registra tu vacante aquí!" />

                <Input
                  attribute={{
                   id: "Area",
                   name: "area",
                   type: "text",
                   required: true,
                   placeholder: "Área",
                   onChange: { handleChange },
                  }}
                handleChange={handleChange}
                />

                <Input
                  attribute={{
                   id: "Rol",
                   name: "rol",
                   type: "text",
                   required: true,
                   placeholder: "Rol",
                   onChange: { handleChange },
                  }}
                handleChange={handleChange}
                />

                <Input
                  attribute={{
                   id: "TipoDeTrabajo",
                   name: "tipoDeTrabajo",
                   type: "text",
                   required: true,
                   placeholder: "Tipo de Trabajo",
                   onChange: { handleChange },
                  }}
                handleChange={handleChange}
                />

                <Input
                  attribute={{
                   id: "Modalidad",
                   name: "modalidad",
                   type: "text",
                   required: true,
                   placeholder: "Modalidad",
                   onChange: { handleChange },
                  }}
                handleChange={handleChange}
                />
                
                <Input
                  attribute={{
                   id: "Descripcion",
                   name: "descripcion",
                   type: "text",
                   required: true,
                   placeholder: "Descripción",
                   onChange: { handleChange },
                  }}
                handleChange={handleChange}
                />
                
                <Input
                  attribute={{
                   id: "Requisitos",
                   name: "requisitos",
                   type: "text",
                   required: true,
                   placeholder: "Requisitos",
                   onChange: { handleChange },
                  }}
                handleChange={handleChange}
                />
                
                <Input
                  attribute={{
                   id: "LinkDelVideoExplicativo",
                   name: "linkDelVideoExplicativo",
                   type: "url", 
                   placeholder: "Link del video explicativo",
                   onChange: { handleChange },
                  }}
                handleChange={handleChange}
                />
               <p className="label-error">{formErrors.linkDelVideoExplicativo}</p>
               
               {/*<label className="label-input">
                  Por favor, escribe una URL válida
                </label>*/}

               <Input
                  attribute={{
                   id: "Sueldo",
                   name: "sueldo",
                   type: "text",
                   required: false,
                   placeholder: "Sueldo",
                   onChange: { handleChange },
                  }}
                handleChange={handleChange}
                />

                <Input
                  attribute={{
                   id: "Localidad",
                   name: "localidad",
                   type: "text",
                   required: true,
                   placeholder: "Localidad",
                   onChange: { handleChange },
                  }}
                handleChange={handleChange}
                />

                <Input
                  attribute={{
                   id: "Pregunta1",
                   name: "pregunta1",
                   type: "text",
                   required: false,
                   placeholder: "Pregunta 1",
                   onChange: { handleChange },
                  }}
                handleChange={handleChange}
                />
                
                <Input
                  attribute={{
                   id: "Pregunta2",
                   name: "pregunta2",
                   type: "text",
                   required: false,
                   placeholder: "Pregunta 2",
                   onChange: { handleChange },
                  }}
                handleChange={handleChange}
                />
                <Input
                  attribute={{
                   id: "Pregunta3",
                   name: "pregunta3",
                   type: "text",
                   required: false,
                   placeholder: "Pregunta 3",
                   onChange: { handleChange },
                  }}
                handleChange={handleChange}
                />

                <div>
                 <button className="guardar-button" type="submit">Registrarse</button>
                </div>
              </div>
            </form>
                     
        );
            
   
    
};

export default RegistroVacantes;

