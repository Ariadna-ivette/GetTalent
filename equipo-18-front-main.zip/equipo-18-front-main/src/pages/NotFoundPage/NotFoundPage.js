import React from 'react'

function NotFoundPage() {
  return (
    <div>404 Not Found Page</div>
  )
}

export default NotFoundPage