import React, { useState, useEffect } from "react";

import "./PostulacionVacante";

import Title from "../../components/Title/Title";
import Label from "../../components/Label/Label";
import Input from "../../components/Input/Input";
// este conecta as historias
import { Link } from "react-router-dom";
import { toHaveFormValues } from "@testing-library/jest-dom/dist/matchers";
import axios from "axios";
import { myAxios } from "../../utils/api";
import "toastify-js/src/toastify.css"
import Toastify from 'toastify-js'
import { Navigate, useNavigate } from "react-router-dom";


export default function PostulacionVacantes() {
    //Aquí van las funciones
    //Primero declaramos los use state

  const [url, setUrl] = useState("");
  const [isUrl, setIsUrl] = useState(false);
  const [errorUrl, setErrorUrl] = useState(false);
  const [error, setError] = useState('');


    const handleSubmit= async (e) =>{
    e.preventDefault(); Toastify({
      text: "Te postulaste a la vacante con éxito",
      duration: 3000
      }).showToast();
        try {
          await myAxios({
            method: "post",
            url: "video/edit/",
            data: {
            linkVideo: "",
            },
          });
        } catch (error) {console.log(error)}
    console.log(url)
    let regExQ =/^(https?:\/\/www.)[a-zA-Z0-9-_$]+.[a-zA-Z]{2,5}$/g;
    let isOk=regExQ.test(url)
    console.log(isOk)
    if(url===""){
      console.log("¡Escribe tu URL!")
      //alert("Escribe tu nombre completo")
      setErrorUrl(true)
    }
    else{setErrorUrl(false)}
    //console.log(e.target.value)
    };

  const handleChange = (e, value) => { navigate("/AGREGAR AQUIIIIIIIIII")
    console.log(e.target.value) //"está imprimiendo en consola"
    setUrl(e.target.value)

     //setUser(value);
    const inputValue = e.target.value;
    const inputName = e.target.name;
    const internalData = url;
    const navigate = useNavigate();
    
    internalData[inputName] = inputValue;
    setUrl(internalData);
    };

    //Aquí regresan los componentes
    return (
        <>
        <form onSubmit={handleSubmit}>
          <div className="postulacion-container">
            <div className="logotipo-login">
            {/*  <img src={LogoGetTalent} /> */}
            </div>
            <div className="postulacion-sections">
              <Title text="GET TALENT" />
              <Label text="Aquí va la URL de tu video" />
              <input
              className="input-url"
              name="url"
              placeholder="Ingrese su URL"
              onChange={handleChange}
            />

            <p className="label-preCargado">Vacantes a las que me puedo postular</p>
            <select name="Vacante" onChange={handleChange}>
            <option value="vacantes">Vacantes</option>
            <option value="vacante1" selected>
            Vacante 1
            </option>
            <option value="vacante2">Vacante 2</option>
            </select>
                <p className="label-errors"> </p>
       {/*} {errorUrl ? <Label text="Escribe tu URL" />:null}</p>*/}
        {/*<p className="reminder">{errorUrl ? <Label 
        text="Tu url debe tener la siguiente estructura http://www._____.com" />:null}</p>*/}
              {errorUrl && (
                <label className="label-alert">
                  {error}
                </label>
              )}
                <button className="button-submit" type="submit" >
                Enviar
              </button>
              </div>
          </div>
        </form>
      </>
    )
};
