import React, { useState } from "react";

import "./Login.css";
import Title from "../../components/Title/Title";
import Label from "../../components/Label/Label";
import Input from "../../components/Input/Input";
import "../../components/Button/Boton.css";
import LogoGetTalent from "../../assets/images/LogoGetTalent.png";
//Este es para conectar las historias
import { Link } from "react-router-dom";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const [user, setUser] = useState("");
  const [password, setPassword] = useState("");
  const [passwordError, setPasswordError] = useState(false);
  const [isLogin, setIsLogin] = useState(false);
  const [errorLogin, setErrorLogin] = useState(false);
  const [error, setError] = useState("");
  const errorpassword =
    "Contraseña debe ser 6 caractéres mínimo, tener una mayúscula, un número y un caracter especial.";
  const navigate = useNavigate();

  function handleSubmit(e) {
    e.preventDefault();
    axios
      .post("https://floating-journey-82290.herokuapp.com/auth/login/", {
        email: user,
        password: password,
      })
      .then(
        (res) =>
          window.localStorage.setItem("codecatstoken", res.data.tokens.access),
        navigate("/Menu") //para guardar en localstorage
      )
      .catch((error) => console.log("error", error));
  }

  return (
    <>
      <div className="login-background">
        <form className="login-container" onSubmit={handleSubmit}>
          <p className="logo-text">GET TALENT</p>
          <p className="H2">Te damos la bienvenida a Get Talent</p>

          <Input //su atributo es un objeto
            attribute={{
              id: "usuario",
              name: "usuario",
              type: "email",
              required: true,
              placeholder: "Ingrese su usuario",
            }}
            handleChange={(e) => setUser(e.target.value)}
          />
          <Input //su atributo es un objeto
            attribute={{
              id: "contrasena",
              name: "contrasena",
              type: "password",
              required: true,
              placeholder: "Ingrese su contraseña",
              pattern:
                "^(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,20}$",
            }}
            handleChange={(e) => setPassword(e.target.value)}
            errorpassword={errorpassword}
          />

          {passwordError && <label className="label-alert">{error}</label>}
         

          <Link className="link-recuperar" to="/RecoverPassword">
            ¿Olvidaste tu contraseña?
          </Link>

          <button className="button-submit">Ingresar</button>
          
          <button
            onClick={() => navigate("/Registro")}
            className="button-register"
          >
            No tengo cuenta
          </button>
        </form>
      </div>
    </>
  );
};

export default Login;
