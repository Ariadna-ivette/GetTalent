import React, { useState } from "react";
import "./AcademicInfo.css";
import Title from "../../components/Title/Title";
import Label from "../../components/Label/Label";
import Input from "../../components/Input/Input";
//import Labelinput from "../../components/Label-input/label-input";
import LogoGetTalent from "../../assets/images/LogoGetTalent.png";
import link from "react-router-dom";
import axios from "axios";
import { myAxios } from "../../utils/api";
import "toastify-js/src/toastify.css"
import Toastify from 'toastify-js'
import { Navigate, useNavigate } from "react-router-dom";

const AcademicInfo = () => {
  const [user, setUser] = useState({
    nombrecompleto: "",
    institucionacademica: "",
    duracion: "",
    estatus: "",
    nivel: "",
  });
  const [nameError, setNameError] = useState(false);
  const [institucionAcademicaError, setInstitucionAcademicaError] =
    useState(false);
  const [duracionError, setDuracionError] = useState(false);
  const [estatusError, setEstatusError] = useState(false);
  const [nivelError, setNivelError] = useState(false);
  const navigate = useNavigate();
  //const [errorUser, setErrorUser] = useState(false);
  //const [error, setError] = useState('');


  const handleSubmit = async (e /*, value*/) => { navigate("/AGREGAR AQUIIIIIIII")
    e.preventDefault();
    /*axios
      .post(
        "https://floating-journey-82290.herokuapp.com/applicant/academicdata/",
        {
          academic_level: user.nivel,
          degree_name: user.nombrecompleto,
          academic_institution: user.institucionacademica,
          degree_duration: user.duracion,
          degree_status: user.estatus,
        })
      .then((res) =>
        window.localStorage.getItem("codecatstoken")
      )
      .catch((error) => console.log("error", error));*/
    try {
      await myAxios({
        method: "post",
        url: "applicant/academicdata/",
        data: {
          academic_level: user.nivel,
          degree_name: user.nombrecompleto,
          academic_institution: user.institucionacademica,
          degree_duration: user.duracion,
          degree_status: user.estatus,
        },
      }); Toastify({
        text: "Guardaste tu información académica con éxito",
        duration: 3000
        }).showToast();
    } catch (error) {console.log(error)}

    /*console.log(user);
    const regExpNumber = /^\d{1,2}$/;
    if (user.nombrecompleto === "") {
      console.log("¡Escribe tu nombre completo!");
      //alert("Escribe tu nombre completo")
      setNameError(true);
    } else {
      setNameError(false);
    }
    if (user.institucionacademica === "") {
      console.log("¡Escribe tu institución académica!");
      //alert("Escribe tu institución academica")
      setInstitucionAcademicaError(true);
    } else {
      setInstitucionAcademicaError(false);
    }
    if (user.duracion === "") {
      console.log("¡Escribe la duración!");
      //alert("Escribe la duración")
      setDuracionError(true);
    } else if (!regExpNumber.test(user.duracion)) {
      const duracionLength = user.duracion.length;
      if (duracionLength > 2) {
        console.log("Sólo se admiten dos dígitos");
      } else {
        console.log("Sólo se permiten dígitos");
      }
      setDuracionError(true);
    } else {
      setDuracionError(false);
    }
    if (user.estatus === "") {
      console.log("¡Selecciona el estatus!");
      //alert("Selecciona el estatus")
      setEstatusError(true);
    } else {
      setEstatusError(false);
    }
    if (user.nivel === "") {
      console.log("¡Selecciona el nivel!");
      //alert("Selecciona el nivel")
      setNivelError(true);
    } else {
      setNivelError(false);
    } */
    //seguir escribiendo if... y luego else...
  };

  const handleChange = (e, value) => {
    //setUser(value);
    const inputValue = e.target.value;
    const inputName = e.target.name;
    const internalData = user;

    internalData[inputName] = inputValue;
    setUser(internalData);
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="academicinfo-container">
        <div className="logotipo-academicInfo">
         
        </div>
        <Title text="GET TALENT" />

        <Label text="Ingresa tu información académica" />

        <p className="label">Nombre de Carrera</p>
        <Input
          attribute={{
            id: "Nombre",
            name: "nombrecompleto",
            type: "text",
            required: "required",
          }}
          handleChange={handleChange}
        />
        {/*es para mostrar el error abajito*/}
        <p className="label-errors">
          {nameError ? <Label text="Escribe tu nombre completo" /> : null}
        </p>

        <p className="label">Institución Académica</p>
        <Input
          attribute={{
            id: "Institucion Academica",
            name: "institucionacademica",
            type: "text",
            required: "required",
          }}
          handleChange={handleChange}
        />
        <p className="label-errors">
          {institucionAcademicaError ? (
            <Label text="Escribe tu Institución Académica" />
          ) : null}
        </p>

        <p className="label">Duración</p>
        <Input
          attribute={{
            id: "Duracion",
            name: "duracion",
            type: "text",
            required: "required",
          }}
          handleChange={handleChange}
        />
        <p>
          {duracionError ? (
            <Label color="red" text="Escribe la duración" />
          ) : null}
        </p>

        <p className="label-preCargado">Estatus</p>
        <select className="input-texto" name="estatus" onChange={handleChange}>
          <option value="Finalizado">Finalizado</option>
          <option value="trunco" selected>
            Trunco
          </option>
          <option value="enCurso">En curso</option>
        </select>
        <p className="label-errors">
          {estatusError ? <Label text="Selecciona el estatus" /> : null}
        </p>

        <p className="label-preCargado">Nivel</p>
        <select className="input-texto" name="nivel" onChange={handleChange}>
          <option value="Carrera técnica">Carrera técnica</option>
          <option value="Universidad" selected>
            Universidad
          </option>
          <option value="Maestría">Maestría</option>
          <option value="Doctorado">Doctorado</option>
          <option value="Curso" selected>
            Curso
          </option>
          <option value="Certificación">Certificación</option>
        </select>
        <p className="label-errors">
          {nivelError ? <Label text="Selecciona el nivel" /> : null}
        </p>
        {/*<label className="label-alert">
                {error}
        </label>*/}

        <button className="button-submit" type="submit">
          Agregar
        </button>
      </div>
    </form>
  );
};

export default AcademicInfo;
