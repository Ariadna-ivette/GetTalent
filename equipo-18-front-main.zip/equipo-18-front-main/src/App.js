import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import "./App.css";
import Login from "./pages/Login/Login";
import Register from "./pages/Register/Register";
import NotFoundPage from "./pages/NotFoundPage/NotFoundPage";
import DatosPerfil from "./pages/DatosPerfil/DatosPerfil";
import Presentation from "./pages/Presentation/Presentation.jsx";
import PerfilEmpresa from "./pages/PerfilEmpresa/PerfilEmpresa";
import AcademicInfo from "./pages/AcademicInfo/AcademicInfo";
import ConfirmRegister from "./pages/ConfirmRegister/ConfirmRegister";
import PerfilIntereses from "./pages/PerfilIntereses/PerfilIntereses";
import RecoverPassword from "./pages/RecoverPassword/RecoverPassword";
import Menu from "./pages/Menu/Menu";
import RegistroVacantes from "./pages/RegistroVacantes/RegistroVacantes.js"
import PostulacionVacante from "./pages/PostulacionVacante/PostulacionVacante.js";


function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/registro" element={<Register />} />
        <Route path="/datosPerfil" element={<DatosPerfil />} />
        <Route path="*" element={<NotFoundPage />} />
        <Route path="/Presentation" element={<Presentation />} />
        <Route path="/PerfilEmpresa" element={<PerfilEmpresa />} />
        <Route path="/ConfirmRegister" element={<ConfirmRegister />} />
        <Route path="/PerfilIntereses" element={<PerfilIntereses />} />
        <Route path="/RecoverPassword" element={<RecoverPassword />} />
        <Route path="/Menu" element={<Menu />} />
        <Route path="/academic-info" element={<AcademicInfo />} />
        <Route path="/registro-vacantes" element={<RegistroVacantes />} />
        <Route path="/postulacion-vacante" element={<PostulacionVacante />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
