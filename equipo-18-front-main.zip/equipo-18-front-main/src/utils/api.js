import axios from "axios";

export const myAxios = ({ method, url, data }) => {
  const token = localStorage.getItem("codecatstoken");
  return axios({
    baseURL: `https://floating-journey-82290.herokuapp.com/`,
    url,
    method,
    data,
    headers: { Authorization: `Bearer ${token}` } //esto se escribe asi siempre 
  });
};
